# Welcome Docker App

A simple Dockerized web app that displays a welcome message, the current time, and the current date.

## Features

- Welcome message
- Live clock updated every second
- Current date
- Responsive design
- Nginx-based Docker image
- Docker Compose support
- GitHub Actions CI/CD
- Automatic publishing to GitHub Container Registry (GHCR)

## Project Structure

```text
welcome-docker-/
├── .github/
│   └── workflows/
│       └── docker.yml
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── index.html
└── README.md
```

## Run with Docker Compose

Make sure Docker Desktop or Docker Engine is installed.

```bash
docker compose up --build
```

Open:

http://localhost:8080

To run in the background:

```bash
docker compose up -d --build
```

To stop:

```bash
docker compose down
```

## Run with Docker

Build the image:

```bash
docker build -t welcome-docker .
```

Run it:

```bash
docker run -d --name welcome-app -p 8080:80 welcome-docker
```

Open:

http://localhost:8080

## GitHub Container Registry

Every push to the `main` branch triggers GitHub Actions.

The workflow builds and publishes:

```text
ghcr.io/mrsaroj646/welcome-docker-:latest
```

Pull the image:

```bash
docker pull ghcr.io/mrsaroj646/welcome-docker-:latest
```

Run the published image:

```bash
docker run -d --name welcome-app -p 8080:80 ghcr.io/mrsaroj646/welcome-docker-:latest
```

## GitHub Actions

The workflow is located at:

```text
.github/workflows/docker.yml
```

It:

1. Checks out the repository.
2. Logs in to GitHub Container Registry.
3. Builds the Docker image.
4. Pushes the `latest` tag.
5. Pushes an immutable image tag based on the commit SHA.

No Docker Hub password or GitHub personal access token is stored in the repository. The workflow uses GitHub's built-in `GITHUB_TOKEN`.

## Repository

GitHub:

https://github.com/Mrsaroj646/welcome-docker-

## License

This project is provided as a simple example for learning Docker, GitHub Actions, and container registries.
